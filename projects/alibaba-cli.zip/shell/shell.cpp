#include <array>
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <fcntl.h>
#include <glob.h>
#include <iostream>
#include <cstring>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

using namespace std;

// This file implements the small shell launched by Alibaba CLI.
// It demonstrates:
// - parsing a command line into commands and shell operators
// - running programs with fork() and execvp()
// - supporting cd, pwd, and exit as built-ins
// - handling <, >, >>, |, &, and wildcard expansion
//
// It is intentionally simple for learning. Features like quotes,
// environment-variable expansion, and job control are not implemented.

// Command data structures

// A single command inside a pipeline.
// Example:
// grep flag < notes.txt
struct Command
{
    vector<string> args;
    string inputFile;
    string outputFile;
    bool appendOutput = false;
};

// A parsed command line.
// Example:
// cat notes.txt | grep flag > hits.txt &
struct Pipeline 
{
    vector<Command> commands;
    bool background = false;
    bool valid = true;
    string error;
};

// Prompt and wildcard helpers

// Return the current working directory for the shell prompt.
string currentDirectory() 
{
    char buffer[4096];

    if (getcwd(buffer, sizeof(buffer)) == nullptr) {
        return "?";
    }

    return string(buffer);

}

// Check whether a token contains shell wildcard characters.
bool hasWildcard(const string& token)
{
    // The [ character supports patterns like file[123].txt.
    return token.find('*') != string::npos ||
        token.find('?') != string::npos ||
        token.find('[') != string::npos;
}

// Expand wildcard arguments like *.cpp before execvp runs the command.
vector<string> expandWildcards(const vector<string>& args)
{
    vector<string> expandedArgs;

    for (const string& arg : args)
    {
        if (!hasWildcard(arg))
        {
            expandedArgs.push_back(arg);
            continue;
        }

        glob_t results;
        memset(&results, 0, sizeof(results));

        int status = glob(arg.c_str(), 0, nullptr, &results);

        if (status == 0)
        {
            for (size_t i = 0; i < results.gl_pathc; i++)
            {
                expandedArgs.push_back(results.gl_pathv[i]);
            }
        }
        else 
        {
            // If the pattern has no matches, keep the original argument.
            expandedArgs.push_back(arg);
        }
        globfree(&results);
    }
    return expandedArgs;
}

// Command-line parsing

// Split the user's command line into tokens.
// Example:
// cat notes.txt | grep flag > hits.txt &
// becomes:
// ["cat", "notes.txt", "|", "grep", "flag", ">", "hits.txt", "&"]
vector<string> tokenize (const string& line)
{
    vector<string> tokens;
    string current;

    for (size_t i=0; i < line.size(); i++)
    {
        char ch = line[i];

        // Spaces separate normal words.
        if (isspace(static_cast<unsigned char>(ch)))
        {
            if (!current.empty())
            {
                tokens.push_back(current);
                current.clear();
            }
        }
        // Special shell symbols become their own tokens.
        else if (ch == '|' || ch == '<' || ch == '>' || ch == '&')
        {
            if (!current.empty())
            {
                tokens.push_back(current);
                current.clear();
            }
            if (ch == '>' && i+1 < line.size() && line[i + 1] == '>')
            {
                tokens.push_back(">>");
                i++;
            }
            else
            {
                tokens.push_back(string(1, ch));
            }
        }
        // Normal char: add it to the current word.
        else
        {
            current += ch;
        }
    }
    // Push the final word if one exists.
    if (!current.empty())
    {
        tokens.push_back(current);
    }
    return tokens;
}

// Turn tokens into a Pipeline structure.
// This understands:
// | pipeline
// < input redirection
// > output redirection
// >> append output redirection
// & background execution
Pipeline parseTokens(const vector<string>& tokens)
{
    Pipeline pipeline;
    Command currentCommand;

    if (tokens.empty())
    {
        pipeline.valid = false;
        pipeline.error = "Empty command.";
        return pipeline;
    }

    for (size_t i = 0; i < tokens.size(); i++)
    {
        const string& token = tokens[i];
        
        if (token == "|")
        {
            if (currentCommand.args.empty())
            {
                pipeline.valid = false;
                pipeline.error = "Missing command";
                return pipeline;
            }
            pipeline.commands.push_back(currentCommand);
            currentCommand = Command();
        }
        else if (token == "<")
        {
            if (i + 1 >= tokens.size())
            {
                pipeline.valid = false;
                pipeline.error = "Missing filename after input redirection.";
                return pipeline;
            }
            currentCommand.inputFile =  tokens[i + 1];
            i++;
        }
        else if (token == ">" || token == ">>")
        {
            if (i + 1 >= tokens.size())
            {
                pipeline.valid = false;
                pipeline.error = "Missing filename after output redirection.";
                return pipeline;
            }
            currentCommand.outputFile =  tokens[i + 1];
            currentCommand.appendOutput = (token == ">>");
            i++;
        }
        else if (token == "&")
        {
            if (i != tokens.size() - 1)
            {
                pipeline.valid = false;
                pipeline.error = "Background symbol & must be at the end.";
                return pipeline;
            }
            pipeline.background = true;
        }
        else
        {
            currentCommand.args.push_back(token);
        }
    }
    if (currentCommand.args.empty())
    {
        pipeline.valid = false;
        pipeline.error = "Missing command";
        return pipeline;
    }

    pipeline.commands.push_back(currentCommand);
    return pipeline;
}

// Built-in commands

// Run commands that the shell itself must handle.
// These do not use fork/exec because they affect the shell process itself.
// Built-ins:
// cd
// pwd
// exit
bool handleBuiltin(const Command& command)
{
    if (command.args.empty())
    {
        return true;
    }

    const string& name = command.args[0];

    if (name == "exit")
    {
        cout << "Exiting Alibaba shell." << endl;
        exit(0);
    }
    if (name == "pwd")
    {
        cout << currentDirectory() << endl;
        return true;
    }
    if (name == "cd")
    {
        if (command.args.size() < 2)
        {
            const char* home = getenv("HOME");

            if (home == nullptr)
            {
                cerr << "cd: HOME environment variable not set " << endl;
                return true;
            }

            if (chdir(home) != 0)
            {
                cerr << "cd: " << strerror(errno) << endl;
            }
            return true;
        }
        
        if (command.args.size() > 2)
    {
        cerr << "cd: too many arguments" << endl;
        return true;
    }

    if (chdir(command.args[1].c_str()) !=0)
    {
        cerr << "cd: " << command.args[1] << ": " << strerror(errno) << endl;
    }
    return true;
    }
    
    return false;
}

// Process execution helpers

// Convert vector<string> args into the char* array execvp needs.
// Example: {"grep", "flag", "notes.txt"} becomes a null-terminated array.
vector<char*> buildExecArgs(vector<string>& args)
{
    vector<char*> execArgs;

    for (string& arg : args)
    {
        execArgs.push_back(arg.data());
    }

    execArgs.push_back(nullptr);
    return execArgs;
}

// Run one command without pipelines.
// Handles:
// Wildcard expansion
// input redirection with <
// output redirection with >
// append redirection with >>
void executeSingleCommand(const Command& command, bool background)
{
    if (command.args.empty())
    {
        return;
    }
    pid_t pid = fork();

    if (pid < 0)
    {
        cerr << "fork failed: " << strerror(errno) << endl;
        return;
    }
    if (pid == 0)
    {
        // Child process: prepare input/output, then replace itself with the command.
        if (!command.inputFile.empty())
        {
            int inputFd = open(command.inputFile.c_str(), O_RDONLY);

            if (inputFd < 0)
            {
                cerr << "input redirection failed: " << command.inputFile
                     << ": " << strerror(errno) << endl;
                exit(1);
            }

            // Make the input file become standard input for this child.
            dup2(inputFd, STDIN_FILENO);
            close(inputFd);
        }
        if(!command.outputFile.empty())
        {
            int flags = O_WRONLY | O_CREAT;

            if (command.appendOutput)
            {
                flags |= O_APPEND;
            }
            else
            {
                flags |= O_TRUNC;
            }
            int outputFd = open(command.outputFile.c_str(), flags, 0644);

            if (outputFd < 0)
            {
                cerr << "output redirection failed: " << command.outputFile
                     << ": " << strerror(errno) << endl;
                exit(1);
            }

            // Make the output file become standard output for this child.
            dup2(outputFd, STDOUT_FILENO);
            close(outputFd);
        }
        vector<string> expandedArgs = expandWildcards(command.args);
        vector<char*> execArgs = buildExecArgs(expandedArgs);

        execvp(execArgs[0], execArgs.data());

        // execvp only returns if the command could not be started.
        cerr << "command not found: " << command.args[0] << endl;
        exit(1);
    }
    // Parent process: either report the background PID or wait for completion.
    if (background)
    {
        cout << "[background pid " << pid << "]" << endl;
    }
    else
    {
        int status;
        waitpid(pid, &status, 0);
    }
}

// Run a full pipeline.
// Example:
// cat notes.txt | grep flag | sort > hits.txt
void executePipeline(const Pipeline& pipeline)
{
    int numberOfCommands = static_cast<int>(pipeline.commands.size());

    if (numberOfCommands == 0)
    {
        return;
    }
    // If there is only one command, use the simpler execution path.
    if (numberOfCommands == 1)
    {
        executeSingleCommand(pipeline.commands[0], pipeline.background);
        return;
    }

    vector<array<int, 2>> pipes(numberOfCommands - 1);

    // Create all pipes needed between commands.
    for (int i = 0; i < numberOfCommands - 1; i++)
    {
        if (pipe(pipes[i].data()) < 0)
        {
            cerr << "pipe failed: " << strerror(errno) << endl;
            return;
        }
    }
    vector<pid_t> childPids;

    for (int i = 0; i < numberOfCommands; i++)
    {
        pid_t pid = fork();

        if (pid < 0)
        {
            cerr << "fork failed: " << strerror(errno) << endl;
            return;
    }
    if (pid == 0)
    {
            // Child process: wire this command into the pipeline.
            const Command& command = pipeline.commands[i];

            // If this isn't the first command, read from the previous pipe.
            if (i > 0)
            {
                dup2(pipes[i-1][0], STDIN_FILENO);
            }

            // If this isn't the last command, write into the next pipe
            if (i < numberOfCommands - 1)
            {
                dup2(pipes[i][1], STDOUT_FILENO);
            }

            // Input redirection only makes sense on the first command.
            if (i == 0 && !command.inputFile.empty())
            {
                int inputFd = open(command.inputFile.c_str(), O_RDONLY);

                if (inputFd < 0)
                {
                    cerr << "input redirection failed: " << command.inputFile << ": " <<strerror(errno) << endl;
                    exit(1);
                }
                dup2(inputFd, STDIN_FILENO);
                close(inputFd);
            }

            // Output redirection only belongs on the last command.
            if (i == numberOfCommands - 1 && !command.outputFile.empty())
            {
                int flags = O_WRONLY | O_CREAT;

                if (command.appendOutput)
                {
                    flags |= O_APPEND;
                }
                else
                {
                    flags |= O_TRUNC;
                }

                int outputFd = open(command.outputFile.c_str(), flags, 0644);

                if (outputFd < 0)
                {
                    cerr << "output redirection failed: " << command.outputFile 
                         << ": " << strerror(errno) << endl;
                    exit(1);
                }

                dup2(outputFd, STDOUT_FILENO);
                close(outputFd);
            }

            // Close pipe file descriptors after dup2 so children do not keep
            // extra pipe ends open and accidentally prevent EOF.
            for (int j = 0; j < numberOfCommands - 1 ; j++)
            {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }

            vector<string> expandedArgs = expandWildcards(command.args);
            vector<char*> execArgs = buildExecArgs(expandedArgs);

            execvp(execArgs[0], execArgs.data());

            // execvp only returns if the command could not be started.
            cerr << "command not found: " << command.args[0] << endl;
            exit(1);
        }

        // Parent keeps track of each child.
        childPids.push_back(pid);
    }
    
    // Parent closes its pipe file descriptors after forking all children.
    for (int i = 0; i < numberOfCommands - 1; i++)
    {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }

    if (pipeline.background)
    {
        cout << "[background pipeline started]" << endl;
    }
    else
    {
        for (pid_t pid: childPids)
        {
            int status;
            waitpid(pid, &status, 0);
        }
    }

}

// Check for finished background processes.
// This prevents finished background jobs from becoming zombie processes.
void cleanupBackgroundProcesses()
{
    int status;
    pid_t pid;

    while ((pid = waitpid(-1, &status, WNOHANG)) > 0)
    {
        cout << "[background pid " << pid << " finished]" << endl;
    }
}

// Main shell loop

int main()
{
    while(true)
    {
        cleanupBackgroundProcesses();

        cout << "alibaba:" << currentDirectory() << "$ ";
        cout.flush();

        string line;

        if (!getline(cin, line))
        {
            cout << endl;
            break;
        }
        if (line.empty())
        {
            continue;
        }

        vector<string> tokens = tokenize(line);
        Pipeline pipeline = parseTokens(tokens);

        if (!pipeline.valid)
        {
            cerr << "shell error: " << pipeline.error << endl;
            continue;
        }

        // Built-ins only run directly when there is one command.
        // Example: cd must change this shell's directory, not a child's.
        if (pipeline.commands.size() == 1)
        {
            if (handleBuiltin(pipeline.commands[0]))
            {
                continue;
            }
        }
        executePipeline(pipeline);
    }
    return 0;
}
