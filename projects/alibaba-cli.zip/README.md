# Alibaba CLI

Python and C++ command-line project for practicing system administration, file management, permissions, processes, packages, databases, and system health utilities.

## Main Files

- `alibaba/` - Python modules for the command-line tools
- `shell/shell.cpp` - C++ command-line shell
- `data/` - SQLite database files

## Portfolio

This project is part of the Hopecore IT portfolio.
