"""Inspect environment variables and runtime configuration safely."""

from dataclasses import dataclass
from pathlib import Path
import os
import platform
import sys

@dataclass(frozen=True)
class EnvironmentInfo:
    python_version: str
    python_executable: Path
    operating_system: str
    system_release: str
    machine: str
    current_directory: Path
    home_directory: Path
    shell: str
    path_entries: tuple[str, ...]
    virtual_environment: Path | None

SAFE_ENVIRONMENT_VARIABLES = (
    "LANG",
    "LC_ALL",
    "TERM",
    "EDITOR",
    "VISUAL",
    "SHELL",
    "USER",
    "LOGNAME",
    "TMPDIR",
    )

def _get_shell() -> str:
    """Return the current user shell when available."""

    shell = os.environ.get("SHELL")

    if shell:
        return shell
    
    return "unknown"

def _get_virtual_environment() -> Path | None:
    """Return the active virtual environment path when present."""

    virtual_environment = os.environ.get("VIRTUAL_ENV")

    if not virtual_environment:
        return None
    
    return Path(virtual_environment).expanduser()

def inspect_environment() -> EnvironmentInfo:
    """Collect safe runtime and environment information."""

    path_value = os.environ.get("PATH", "")
    path_entries = tuple(
        entry
        for entry in path_value.split(os.pathsep)
        if entry
    )

    return EnvironmentInfo(
        python_version=platform.python_version(),
        python_executable=Path(sys.executable),
        operating_system=platform.system(),
        system_release=platform.release(),
        machine=platform.machine(),
        current_directory=Path.cwd(),
        home_directory=Path.home(),
        shell=_get_shell(),
        path_entries=path_entries,
        virtual_environment=_get_virtual_environment(),
    )

def get_safe_environment_variables() -> dict[str, str]:
    """Return a limited set of non-sensitive environment variables."""

    safe_variables: dict[str, str] = {}

    for variable_name in SAFE_ENVIRONMENT_VARIABLES:
        value = os.environ.get(variable_name)

        if value is not None:
            safe_variables[variable_name] = value

    return safe_variables

def environment_to_dict(info: EnvironmentInfo) -> dict[str, object]:
    """Convert environment information into a serializable dictionary."""

    return {
        "python_version": info.python_version,
        "python_executable": str(info.python_executable),
        "operating_system": info.operating_system,
        "system_release": info.system_release,
        "machine": info.machine,
        "current_directory":str(info.current_directory),
        "home_directory":str(info.home_directory),
        "shell": info.shell,
        "path_entries":list(info.path_entries),
        "virtual_environment":(
            str(info.virtual_environment)
            if info.virtual_environment is not None
            else None
        ),
    }

def format_environment_info(info: EnvironmentInfo) -> str:
    """Format environment information for terminal output."""

    if info.virtual_environment is None:
        virtual_environment = "Not active"
    else:
        virtual_environment = str(info.virtual_environment)

    path_text = "\n".join(
        f"- {entry}"
        for entry in info.path_entries
    )

    if not path_text:
        path_text = "- No PATH entries found"

    return "\n".join(
        [
            "Alibaba CLI - Environment Report",
            f"Python version: {info.python_version}",
            f"Python executable: {info.python_executable}",
            f"Operating system: {info.operating_system}",
            f"System release: {info.system_release}",
            f"Machine architecture: {info.machine}",
            f"Current directory: {info.current_directory}",
            f"Home directory: {info.home_directory}",
            f"Shell: {info.shell}",
            f"Virtual environment: {virtual_environment}",
            "PATH entries:",
            path_text,
        ]
    )

def format_safe_environment_variables(
    variables: dict[str, str],
) -> str:
    """Format approved environment variables for terminal output."""

    if not variables:
        return "No approved environment variables were found."
    
    lines = ["Alibaba CLI - Safe Environment Variables"]

    for variable_name in sorted(variables):
        lines.append(
            f"{variable_name}={variables[variable_name]}"
        )

    return "\n".join(lines)

