from pathlib import Path
import subprocess
import sys

def launch_shell() -> int:
    project_root = Path(__file__).resolve().parent.parent
    shell_binary = project_root / "shell" / "shell"

    if not shell_binary.exists():
        print("Alibaba shell binary was not found.", file=sys.stderr)
        print(
            "Compile it with: "
            "clang++ -std=c++17 -Wall -Wextra -pedantic "
            "shell/shell.cpp -o shell/shell",
            file=sys.stderr,
        )
        return 1
    
    try:
        completed_process = subprocess.run(
            [str(shell_binary)],
            check=False,
        )
        return completed_process.returncode
    
    except OSError as error:
        print(f"Unable to launch Alibaba shell: {error}", file=sys.stderr)
        return 1
    
def main() -> int:
    arguments = sys.argv[1:]

    if not arguments:
        print("Alibaba CLI")
        print()
        print("Usage:")
        print("   python3 -m alibaba shell")
        return 0
    
    command = arguments[0]

    if command == "shell":
        return launch_shell()
    
    if command in {"help", "--help", "-h"}:
        print("Alibaba CLI")
        print()
        print("Commands:")
        print("  shell    Launch the Alibaba C++ shell")
        return 0
    
    print(f"Unknown Alibaba command: {command}", file=sys.stderr)
    print("Run 'python3 -m alibaba --help' for available commands.")
    return 1