"""Inspect installed Python packages and package-management configuration."""

from dataclasses import dataclass
import importlib.metadata
import sys

@dataclass(frozen=True)
class PackageInfo:
    name: str
    version: str

def list_installed_packages() -> list[PackageInfo]:
    """Return installed Python packages sorted by name."""

    packages = [
        PackageInfo(
            name=distribution.metadata.get(
                "Name",
                distribution.metadata.get("Summary", "unknown"),
            ),
            version=distribution.version,
        )
        for distribution in importlib.metadata.distributions()
    ]

    return sorted(
        packages,
        key=lambda package: package.name.lower(),
    )

def find_packages(
    query: str,
    packages: list[PackageInfo] | None = None,
) -> list[PackageInfo]:
    """Return installed packages whose names contain the query."""

    if packages is None:
        packages = list_installed_packages()

    normalized_query = query.strip().lower()

    if not normalized_query:
        return packages
    
    return [
        package
        for package in packages
        if normalized_query in package.name.lower()
    ]

def package_to_dict(package: PackageInfo) -> dict[str, str]:
    """Convert package information into a serializable dictionary"""

    return {
        "name": package.name,
        "version": package.version,
    }

def packages_to_dict(
    packages: list[PackageInfo],
) -> list[dict[str, str]]:
    """Convert multiple package records into dictionaries"""

    return [
        package_to_dict(package)
        for package in packages
    ]

def get_python_package_manager() -> str:
    """Return the package manager command for the current Python runtime"""

    return f"{sys.executable} -m pip"

def format_package_info(package: PackageInfo) -> str:
    """Format one installed package for terminal output."""

    return f"{package.name}=={package.version}"

def format_package_list(
    packages: list[PackageInfo],
) -> str:
    """Format installed packages for terminal output."""

    if not packages:
        return "No installed Python packages were found"
    
    lines = [
        "Alibaba CLI - Installed Python Packages",
        f"Package count: {len(packages)}",
        "",
    ]

    lines.extend(
        format_package_info(package)
        for package in packages
    )

    return "\n".join(lines)

def format_package_search(
    query: str,
    packages: list[PackageInfo],
) -> str:
    """Format package-search results for terminal output."""

    normalized_query = query.strip()

    if not packages:
        return "\n".join(
            [
                "Alibaba CLI - Package Search",
                f"Query: {normalized_query}",
                "No matching packages were found.",
            ]
        )
    
    lines = [
        "Alibaba CLI - Package Search",
        f"Query: {normalized_query}",
        f"Matches: {len(packages)}",
        "",
    ]

    lines.extend(
        format_package_info(package)
        for package in packages
    )

    return "\n".join(lines)