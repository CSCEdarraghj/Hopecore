"""System-health monitoring and reporting utilities for Alibaba CLI."""

from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
import os
from pathlib import Path
import platform
import shutil
from typing import Any

import psutil

@dataclass(frozen=True)
class SystemHealth:
    """A snapshot of the computer's current health and resource usage."""

    hostname: str
    operating_system: str
    architecture: str
    boot_time: str
    uptime_seconds: int
    cpu_percent: float
    cpu_count: int
    memory_percent: float
    memory_used_bytes: int
    memory_total_bytes: int
    disk_percent: float
    disk_used_bytes: int
    disk_total_bytes: int
    load_average_1m: float | None
    load_average_5m: float | None
    load_average_15m: float | None
    process_count: int
    status: str

def bytes_to_human(size: int | float) -> str:
    """Convert a byte count into a readable size such as MiB or GiB."""

    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    value = float(size)

    for unit in units:
        if abs(value) < 1024.0 or unit == units[-1]:
            return f"{value:.2f} {unit}"
        
        value /= 1024.0

    return f"{value:.2f} PiB"

def format_uptime(seconds: int | float) -> str:
    """Convert an uptime in seconds into a readable duration."""
    
    total_seconds = max(0, int(seconds))
    duration = timedelta(seconds=total_seconds)

    days = duration.days
    hours, remainder = divmod(duration.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts: list[str] = []

    if days:
        parts.append(f"{days}d")

    if hours or days:
        parts.append(f"{hours}h")

    if minutes or hours or days:
        parts.append(f"{minutes}m")

    parts.append(f"{seconds}s")

    return " ".join(parts)

def get_load_average() -> tuple[float | None, float | None, float | None]:
    """Return the one-, five-, and fifteen-minute system load averages."""

    if not hasattr(os, "getloadavg"):
        return None, None, None
    
    try:
        one_minute, five_minutes, fifteen_minutes = os.getloadavg()
    except OSError:
        return None, None, None

    return (
        round(one_minute, 2),
        round(five_minutes, 2),
        round(fifteen_minutes, 2),
    )

def evaluate_health(
    cpu_percent: float,
    memory_percent: float,
    disk_percent: float,
) -> str:
    """Classify overall health from CPU, memory, and disk usage."""

    highest_usage = max(cpu_percent, memory_percent, disk_percent)

    if highest_usage >= 95.0:
        return "critical"
    
    if highest_usage >= 85.0:
        return "warning"
    
    return "healthy"

def get_system_health(
    disk_path: str | Path | None = None,
    cpu_interval: float = 0.2,
) -> SystemHealth:
    """Collect and return a complete system-health snapshot."""

    selected_disk = Path(disk_path) if disk_path is not None else Path.home()
    selected_disk = selected_disk.expanduser().resolve()

    if not selected_disk.exists():
        raise FileNotFoundError(
            f"Disk path does not exist: {selected_disk}"
        )
    
    boot_timestamp = psutil.boot_time()
    boot_datetime = datetime.fromtimestamp(boot_timestamp)

    uptime_seconds = max(
        0,
        int(datetime.now().timestamp() - boot_timestamp),
    )

    cpu_percent = round(
        psutil.cpu_percent(interval=cpu_interval),
        1,
    )

    cpu_count = psutil.cpu_count(logical=True) or 0

    memory = psutil.virtual_memory()
    disk = shutil.disk_usage(selected_disk)

    memory_percent = round(float(memory.percent), 1)

    if disk.total:
        disk_percent = round(
            (disk.used / disk.total) * 100.0,
            1,
        )
    else:
        disk_percent = 0.0

    load_1m, load_5m, load_15m = get_load_average()

    status = evaluate_health(
        cpu_percent=cpu_percent,
        memory_percent=memory_percent,
        disk_percent=disk_percent,
    )

    return SystemHealth(
        hostname=platform.node() or "unknown",
        operating_system=(
            f"{platform.system()} {platform.release()}"
        ),
        architecture=platform.machine() or "unknown",
        boot_time=boot_datetime.isoformat(timespec="seconds"),
        uptime_seconds=uptime_seconds,
        cpu_percent=cpu_percent,
        cpu_count=cpu_count,
        memory_percent=memory_percent,
        memory_used_bytes=int(memory.used),
        memory_total_bytes=int(memory.total),
        disk_percent=disk_percent,
        disk_used_bytes=int(disk.used),
        disk_total_bytes=int(disk.total),
        load_average_1m=load_1m,
        load_average_5m=load_5m,
        load_average_15m=load_15m,
        process_count=len(psutil.pids()),
        status=status,
    )

def health_to_dict(
    health: SystemHealth,
) -> dict[str, Any]:
    """Convert a system-health snapshot into a dictionary."""

    return asdict(health)

def format_load_average(
    health: SystemHealth,
) -> str:
    """Format the health snapshot's load average."""

    load_values = (
        health.load_average_1m,
        health.load_average_5m,
        health.load_average_15m,
    )

    if any(value is None for value in load_values):
        return "Unavailable"
    
    return " / ".join(
        f"{value:.2f}"
        for value in load_values
        if value is not None
    )

def format_system_health(
    health: SystemHealth,
) -> str:
    """Format a system-health snapshot for terminal output."""

    lines = [
        "System Health",
        "=============",
        f"Status:       {health.status.upper()}",
        f"Hostname:     {health.hostname}",
        f"OS:           {health.operating_system}",
        f"Architecture: {health.architecture}",
        f"Boot time:    {health.boot_time}",
        f"Uptime:       {format_uptime(health.uptime_seconds)}",
        "",
        "Resource Usage",
        "--------------",
        (
            f"CPU:          {health.cpu_percent:.1f}% "
            f"across {health.cpu_count} logical cores"
        ),
        (
            f"Memory:       {health.memory_percent:.1f}% "
            f"({bytes_to_human(health.memory_used_bytes)} / "
            f"{bytes_to_human(health.memory_total_bytes)})"
        ),
        (
            f"Disk:         {health.disk_percent:.1f}% "
            f"({bytes_to_human(health.disk_used_bytes)} / "
            f"{bytes_to_human(health.disk_total_bytes)})"
        ),
        f"Load average: {format_load_average(health)}",
        f"Processes:    {health.process_count}",
    ]

    return "\n".join(lines)
