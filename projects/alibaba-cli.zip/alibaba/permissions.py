"""Inspect local file and directory permissions, ownership, and access settings."""
from dataclasses import dataclass
from pathlib import Path
import os
import grp
import pwd
import stat

@dataclass(frozen=True)
class PermissionInfo:
    path: Path
    exists: bool
    is_directory: bool
    is_file: bool
    is_symlink: bool
    owner: str
    group: str
    owner_id: int
    group_id: int
    octal_mode: str
    symbolic_mode: str
    readable: bool
    writable: bool
    executable: bool
    world_readable: bool
    world_writable: bool
    world_executable: bool

def _owner_name(owner_id: int) -> str:
    """Return the account name for a user ID."""

    try:
        return pwd.getpwuid(owner_id).pw_name
    except KeyError:
        return str(owner_id)
    
def _group_name(group_id: int) -> str:
    """Return the account name for a group ID."""

    try:
        return grp.getgrgid(group_id).gr_name
    except KeyError:
        return str(group_id)
    
def inspect_permissions(path: str | Path) -> PermissionInfo:
    """Collect permission and ownership information for one path."""

    target = Path(path).expanduser()
    exists = os.path.lexists(target)

    if not exists:
        return PermissionInfo(
            path=target,
            exists=False,
            is_directory=False,
            is_file=False,
            is_symlink=False,
            owner="unknown",
            group="unknown",
            owner_id=-1,
            group_id=-1,
            octal_mode="----",
            symbolic_mode="----------",
            readable = False,
            writable = False,
            executable = False,
            world_readable=False,
            world_writable=False,
            world_executable=False,
        )
    
    path_stat = target.lstat()
    mode = path_stat.st_mode

    return PermissionInfo(
        path=target,
        exists=True,
        is_directory=target.is_dir(),
        is_file=target.is_file(),
        is_symlink=target.is_symlink(),
        owner=_owner_name(path_stat.st_uid),
        group=_group_name(path_stat.st_gid),
        owner_id=path_stat.st_uid,
        group_id=path_stat.st_gid,
        octal_mode=f"{stat.S_IMODE(mode):04o}",
        symbolic_mode=stat.filemode(mode),
        readable = os.access(target, os.R_OK),
        writable = os.access(target, os.W_OK),
        executable = os.access(target, os.X_OK),
        world_readable=bool(mode & stat.S_IROTH),
        world_writable=bool(mode & stat.S_IWOTH),
        world_executable=bool(mode & stat.S_IXOTH),
    )

def permissions_to_dict(info: PermissionInfo) -> dict[str, object]:
    """Convert a permission report into a serializable dictionary."""

    return {
        "path": str(info.path),
        "exists": info.exists,
        "is_directory": info.is_directory,
        "is_file": info.is_file,
        "is_symlink": info.is_symlink,
        "owner": info.owner,
        "group": info.group,
        "owner_id": info.owner_id,
        "group_id": info.group_id,
        "octal_mode": info.octal_mode,
        "symbolic_mode": info.symbolic_mode,
        "readable": info.readable,
        "writable": info.writable,
        "executable": info.executable,
        "world_readable": info.world_readable,
        "world_writable": info.world_writable,
        "world_executable": info.world_executable,
    }

def format_permission_info(info: PermissionInfo) -> str:
    """Format permission information for terminal output."""

    if not info.exists:
        return "\n".join(
            [
                "Alibaba CLI - Permission Report",
                f"Path: {info.path}",
                "Status: Path does not exist",
            ]
        )
    
    if info.is_symlink:
        path_type = "Symbolic link"
    elif info.is_directory:
        path_type = "Directory"
    elif info.is_file:
        path_type = "File"
    else:
        path_type = "Other"

    warnings: list[str] = []

    if info.world_writable:
        warnings.append("Path is writable by all users.")

    if info.world_executable and info.is_file:
        warnings.append("Path is executable by all users.")

    if not warnings:
        warnings.append("No obvious permission warnings detected.")

    warning_text = "\n".join(f"- {warning}" for warning in warnings)

    return "\n".join(
        [
            "Alibaba CLI - Permission Report",
            f"Path: {info.path}",
            f"Type: {path_type}",
            f"Owner: {info.owner} ({info.owner_id})",
            f"Group: {info.group} ({info.group_id})",
            f"Octal permissions: {info.octal_mode}",
            f"Symbolic permissions: {info.symbolic_mode}",
            f"Readable by current user: {info.readable}",
            f"Writable by current user: {info.writable}",
            f"Executable by current user: {info.executable}",
            f"World readable: {info.world_readable}",
            f"World writable: {info.world_writable}",
            f"World executable: {info.world_executable}",
            "Warnings:",
            warning_text,
        ]
    )

def inspect_multiple_paths(
    paths: list[str | Path],
) -> list[PermissionInfo]:
    """Inspect multiple files or directories."""

    return [inspect_permissions(path) for path in paths]
    
    
    


    

    
