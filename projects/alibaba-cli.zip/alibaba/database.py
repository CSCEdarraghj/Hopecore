"""SQLite database support for Alibaba CLI"""

from pathlib import Path
import sqlite3

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIRECTORY = PROJECT_ROOT / "data"
DATABASE_PATH = DATA_DIRECTORY / "alibaba.db"

def connect_database() -> sqlite3.Connection:
    """Open the Alibaba SQLite database."""

    DATA_DIRECTORY.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row

    return connection

def initialize_database() -> None:
    """Create Alibaba database tables when they do not already exist."""

    with connect_database() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT NOT NULL,
            ip_address TEXT,
            mac_address TEXT,
            operating_system TEXT,
            vendor TEXT,
            notes TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

        connection.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS
            inventory_hostname_ip_index
            ON inventory(hostname, ip_address)
            """
        )

def database_status() -> dict[str, object]:
    """Return basic information about the Alibaba database."""

    initialize_database()

    with connect_database() as connection:
        row = connection.execute(
            "SELECT COUNT(*) AS inventory_count FROM inventory"
        ).fetchone()

    return {
        "database_path": str(DATABASE_PATH),
        "inventory_count": row["inventory_count"],
    }