"""Read-only filesystem inspection tools for Alibaba CLI."""

from __future__ import annotations

import os
import stat
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

@dataclass(frozen=True)
class FileInformation:
    """Structured information about one filesystem path."""

    path: str
    name: str
    path_type: str
    size_bytes: int
    owner_id: int
    group_id: int
    permissions: str
    octal_permissions: str
    created_at: str
    modified_at: str
    accessed_at: str
    is_hidden: bool
    is_readable: bool
    is_writable: bool
    is_executable: bool

@dataclass(frozen=True)
class DirectoryEntry:
    """Summary information for one item inside a directory."""

    path: str
    name: str
    path_type: str
    size_bytes: int
    permissions: str
    modified_at: str

def resolve_existing_path(path: str | Path) -> Path:
    """Resolve and validate an existing filesystem path."""

    resolved_path = Path(path).expanduser().resolve()

    if not resolved_path.exists():
        raise FileNotFoundError(
            f"Filesystem path does not exist: {resolved_path}"
        )
    
    return resolved_path

def determine_path_type(path: Path) -> str:
    """Return a readable description of a filesystem path type."""

    if path.is_symlink():
        return "symbolic-link"
    
    if path.is_file():
        return "file"
    
    if path.is_dir():
        return "directory"
    
    if path.is_socket():
        return "socket"
    
    if path.is_fifo():
        return "named-pipe"
    
    if path.is_block_device():
        return "block-device"
    
    if path.is_char_device():
        return "character-device"
    
    return "other"

def format_timestamp(timestamp: float) -> str:
    """Convert a Unix timestamp into a local ISO-formatted string."""

    return datetime.fromtimestamp(timestamp).astimezone().isoformat(
        timespec="seconds"
    )

def permission_string(mode: int) -> str:
    """Convert a numeric file mode into an ls-style permission string."""

    return stat.filemode(mode)

def octal_permission_string(mode: int) -> str:
    """Return only the permission bits in four-digit octal form."""

    return f"{stat.S_IMODE(mode):04o}"

def inspect_path(path: str | Path) -> FileInformation:
    """Collect read-only metadata for a file or directory."""

    resolved_path = resolve_existing_path(path)
    path_stat = resolved_path.lstat()

    return FileInformation(
        path=str(resolved_path),
        name=resolved_path.name or str(resolved_path),
        path_type=determine_path_type(resolved_path),
        size_bytes=path_stat.st_size,
        owner_id=path_stat.st_uid,
        group_id=path_stat.st_gid,
        permissions=permission_string(path_stat.st_mode),
        octal_permissions=octal_permission_string(path_stat.st_mode),
        created_at=format_timestamp(path_stat.st_ctime),
        modified_at=format_timestamp(path_stat.st_mtime),
        accessed_at=format_timestamp(path_stat.st_atime),
        is_hidden=resolved_path.name.startswith("."),
        is_readable=os.access(resolved_path, os.R_OK),
        is_writable=os.access(resolved_path, os.W_OK),
        is_executable=os.access(resolved_path, os.X_OK),
    )

def file_information_to_dict(
    information: FileInformation,
) -> dict[str, Any]:
    """Convert file information into a serializable dictionary."""

    return asdict(information)

def list_directory(
    path: str | Path,
    include_hidden: bool = False,
) -> list[DirectoryEntry]:
    """Return sorted read-only information for directory contents."""

    resolved_path = resolve_existing_path(path)

    if not resolved_path.is_dir():
        raise NotADirectoryError(
            f"Filesystem path is not a directory: {resolved_path}"
        )
    
    entries: list[DirectoryEntry] = []

    for child in resolved_path.iterdir():
        if not include_hidden and child.name.startswith("."):
            continue

        try:
            child_stat = child.lstat()
        except OSError:
            continue

        entries.append(
            DirectoryEntry(
                path=str(child),
                name=child.name,
                path_type=determine_path_type(child),
                size_bytes=child_stat.st_size,
                permissions=permission_string(child_stat.st_mode),
                modified_at=format_timestamp(child_stat.st_mtime),
            )
        )

    return sorted(
        entries,
        key=lambda entry: (
            entry.path_type != "directory",
            entry.name.lower(),
        ),
    )

def directory_entry_to_dict(
    entry: DirectoryEntry,
) -> dict[str, Any]:
    """Convert a directory entry into a serializable dictionary."""

    return asdict(entry)