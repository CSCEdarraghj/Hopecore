"""Read-only process inspection tools for Alibaba CLI."""

from __future__ import annotations

import subprocess
from dataclasses import asdict, dataclass
from typing import Any

@dataclass(frozen=True)
class ProcessInformation:
    """Structured information about one running process."""

    pid: int
    parent_pid: int
    user: str
    cpu_percent: float
    memory_percent: float
    status: str
    elapsed_time: str
    command: str

def parse_process_line(line:str) -> ProcessInformation:
    """Convert one ps command output line into process information."""
    
    parts = line.strip().split(None, 7)

    if len(parts) != 8:
        raise ValueError(f"Unexpected process output: {line}")
    
    return ProcessInformation(
        pid=int(parts[0]),
        parent_pid=int(parts[1]),
        user=parts[2],
        cpu_percent=float(parts[3]),
        memory_percent=float(parts[4]),
        status=parts[5],
        elapsed_time=parts[6],
        command=parts[7],
    )

def list_processes() -> list[ProcessInformation]:
    """Return information about all processes visible to the current user."""
    
    command = [
        "ps",
        "-axo",
        "pid=,ppid=,user=,%cpu=,%mem=,stat=,etime=,command=",
    ]

    try:
        completed_process = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as error:
        raise RuntimeError("The ps command is not available.") from error
    except subprocess.CalledProcessError as error:
        message = error.stderr.strip() or "Process inspection failed."
        raise RuntimeError(message) from error
    
    processes: list[ProcessInformation] = []

    for line in completed_process.stdout.splitlines():
        if not line.strip():
            continue

        try:
            processes.append(parse_process_line(line))
        except ValueError:
            continue

    return processes

def find_processes(
    search_term: str,
) -> list[ProcessInformation]:
    """Return processes whose command contains the search term."""

    normalized_term = search_term.strip().lower()

    if not normalized_term:
        raise ValueError("Process search term cannot be empty.")
    
    return [
        process
        for process in list_processes()
        if normalized_term in process.command.lower()
    ]

def get_process(
    pid: int,
) -> ProcessInformation | None:
    """Return one process by PID, or None when it is not running."""

    if not isinstance(pid, int):
        raise TypeError("PID must be an integer.")
    
    if pid <= 0:
        raise ValueError("PID must be greater than zero.")
    
    for process in list_processes():
        if process.pid == pid:
            return process
        
    return None

def processes_by_cpu(
    limit: int = 10,
) -> list[ProcessInformation]:
    """Return processes using the most CPU."""

    if limit <= 0:
        raise ValueError("Limit must be greater than zero.")
    
    return sorted(
        list_processes(),
        key=lambda process: process.cpu_percent,
        reverse=True,
    )[:limit]

def processes_by_memory(
    limit: int = 10,
) -> list[ProcessInformation]:
    """Return processes using the most memory."""

    if limit <= 0:
        raise ValueError("Limit must be greater than zero.")
    
    return sorted(
        list_processes(),
        key=lambda process: process.memory_percent,
        reverse=True,
    )[:limit]
    
def process_information_to_dict(
    process: ProcessInformation,
) -> dict[str, Any]:
    """Convert process information into a serializable dictionary."""

    return asdict(process)