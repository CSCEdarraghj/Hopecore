from __future__ import annotations

import os
import platform
import shutil
import socket
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from .database import connect_database, initialize_database

@dataclass(frozen=True)
class DiskInventory:
    """Structured disk-capacity information for one filesystem path."""
    path: str
    total_bytes: int
    used_bytes: int
    free_bytes: int

@dataclass(frozen=True)
class SystemInventory:
    """Structured information about the local operating system and hardware."""
    hostname: str
    ip_address: str
    mac_address: str
    operating_system: str
    operating_system_release: str
    operating_system_version: str
    architecture: str
    processor: str
    python_version: str
    cpu_count: int | None
    home_directory: str
    disk: DiskInventory

def collect_disk_inventory(path: Path) -> DiskInventory:
    """Collect total, used, and free space for the filesystem containing path."""

    resolved_path = path.expanduser().resolve()
    if not resolved_path.exists():
        raise FileNotFoundError(
            f"Disk inspection path does not exist: {resolved_path}"
        )
    usage = shutil.disk_usage(resolved_path)

    return DiskInventory(
        path=str(resolved_path),
        total_bytes=usage.total,
        used_bytes=usage.used,
        free_bytes=usage.free,
    )

def collect_ip_address() -> str:
    """Return the local machine's primary IPv4 address when available."""

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
            connection.connect(("8.8.8.8", 80))
            return connection.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except socket.gaierror:
            return "unknown"
        
def collect_mac_address() -> str:
    """Return the local machine's hardware address in colon-separated form."""

    mac_number = uuid.getnode()
    mac_hex = f"{mac_number:012x}"

    return ":".join(
        mac_hex[index:index + 2]
        for index in range(0, 12, 2)
    )

def collect_system_inventory(
    disk_path: Path | None = None,
) -> SystemInventory:
    """Collect a cross platform snapshot of the local machine."""
    
    selected_disk_path = disk_path or Path.home()

    return SystemInventory(
        hostname=socket.gethostname(),
        ip_address=collect_ip_address(),
        mac_address=collect_mac_address(),
        operating_system=platform.system(),
        operating_system_release=platform.release(),
        operating_system_version=platform.version(),
        architecture=platform.machine(),
        processor=platform.processor() or "unknown",
        python_version=platform.python_version(),
        cpu_count=os.cpu_count(),
        home_directory=str(Path.home()),
        disk=collect_disk_inventory(selected_disk_path),
    )

def inventory_to_dict(
    inventory: SystemInventory,
) -> dict[str, Any]:
    """Convert nested inventory dataclasses into a dictionary."""

    return asdict(inventory)

def format_bytes(byte_count: int) -> str:
    """Convert a byte count into a readable unit such as MB or GB."""

    if byte_count < 0:
        raise ValueError("Byte count cannot be negative.")
    
    units = ("B", "KB", "MB", "GB", "TB", "PB")
    value = float(byte_count)

    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.2f} {unit}"

        value /= 1024

    return f"{byte_count} B"

def format_inventory_text(
    inventory: SystemInventory,
) -> str:
    """Render inventory data as readable terminal output."""

    disk = inventory.disk

    lines = [
        "Alibaba CLI - System Inventory",
        "==============================",
        f"Hostname:             {inventory.hostname}",
        f"IP address:           {inventory.ip_address}",
        f"MAC address:          {inventory.mac_address}",
        f"Operating system:     {inventory.operating_system}",
        f"OS release:           {inventory.operating_system_release}",
        f"OS version:           {inventory.operating_system_version}",
        f"Architecture:         {inventory.architecture}",
        f"Processor:            {inventory.processor}",
        f"Logical CPU count:    {inventory.cpu_count}",
        f"Python version:       {inventory.python_version}",
        f"Home directory:       {inventory.home_directory}",
        "",
        "Disk",
        "----",
        f"Path:                 {disk.path}",
        f"Total:                {format_bytes(disk.total_bytes)}",
        f"Used:                 {format_bytes(disk.used_bytes)}",
        f"Free:                 {format_bytes(disk.free_bytes)}",
    ]

    return "\n".join(lines)

def save_system_inventory(
    inventory: SystemInventory,
    notes: str | None = None,
) -> int:
    """Insert or update the local machine in the Alibaba inventory database."""

    initialize_database()

    operating_system = (
        f"{inventory.operating_system} "
        f"{inventory.operating_system_release}"
    ).strip()

    with connect_database() as connection:
        connection.execute(
                """
                INSERT INTO inventory (
                    hostname,
                    ip_address,
                    mac_address,
                    operating_system,
                    vendor,
                    notes
            )
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(hostname, ip_address)
            DO UPDATE SET
                mac_address = excluded.mac_address,
                operating_system = excluded.operating_system,
                vendor = excluded.vendor,
                notes = excluded.notes,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                inventory.hostname,
                inventory.ip_address,
                inventory.mac_address,
                operating_system,
                platform.machine(),
                notes,
            ),
        )
        
        row = connection.execute(
                """
                SELECT id
                FROM inventory
                WHERE hostname = ? AND ip_address = ?
                """,
                (
                    inventory.hostname,
                    inventory.ip_address,
                ),
            ).fetchone()

    if row is None:
        raise RuntimeError("Inventory record could not be retrieved.")
    
    return int(row["id"])

def list_saved_inventory() -> list[dict[str, Any]]:
    """Return all stored inventory records."""

    initialize_database()

    with connect_database() as connection:
        rows = connection.execute(
            """
            SELECT
                id,
                hostname,
                ip_address,
                mac_address,
                operating_system,
                vendor,
                notes,
                created_at,
                updated_at
            FROM inventory
            ORDER BY hostname, ip_address
            """
        ).fetchall()

    return [dict(row) for row in rows]